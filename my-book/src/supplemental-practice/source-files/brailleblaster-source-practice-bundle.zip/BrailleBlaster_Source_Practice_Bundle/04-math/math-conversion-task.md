# Math conversion task

Open `math-lesson.tex` in the clean source folder.

1. Identify the document-level structure and the two displayed equations.
2. Distinguish inline variables from the displayed rate equation.
3. Record how units are attached to quantities.
4. Import or recreate the content in BrailleBlaster using the workflow taught in the math lesson.
5. Proofread the resulting math and surrounding literary context independently.

Expected mathematical relationship: average rate equals distance divided by elapsed time. The numerical example evaluates to 4 kilometres per hour.
