# BrailleBlaster source-file practice bundle

This bundle contains synthetic, classroom-safe source documents for import, conversion, structure repair, and production practice. No personal data or copyrighted textbook passages are included.

## Contents
- `01-clean/` well-formed source files for baseline import practice
- `02-challenge/` intentionally flawed files for diagnosis and repair
- `03-graphics/` a simple tactile-graphic SVG and description brief
- `04-math/` LaTeX math source and a short conversion brief

## Suggested sequence
1. Import `01-clean/field-guide.html` and inspect heading hierarchy, lists, table, and emphasis.
2. Import `01-clean/lesson-notes.xml`; compare its semantic structure with the rendered content.
3. Open `01-clean/math-lesson.tex` and practice the math workflow described in the lesson materials.
4. Diagnose `02-challenge/flawed-lesson.html` and record every structural defect before editing.
5. Inspect `02-challenge/flawed-nimas.xml` as a markup-validation exercise. It is intentionally incomplete and is not a valid production NIMAS package.
6. Use `03-graphics/` to practice deciding what information belongs in a concise tactile graphic description.

## Important
These are instructional specimens, not certified NIMAS source packages or production-ready publishing files. Validate all output against current project requirements and the applicable Braille code. The SVG is a simple geometric teaching graphic, not a tactile-ready manufacturing file.
