# Tactile graphic description task

Use `wetland-zones.svg` as a visual reference.

**Task:** Write:
1. A one-sentence overview of the whole graphic.
2. A left-to-right description of the three zones.
3. One note identifying the boundary between water and land.

Avoid decorative details. Preserve spatial relationships. Do not infer ecological facts that are not shown. Consider whether the graphic's labels and textures would remain distinguishable in a tactile version.
