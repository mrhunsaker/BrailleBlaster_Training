---
title: Markdown Syntax Tour
author: Test Author
---

# Heading level 1

## Heading level 2

### Heading level 3

#### Heading level 4

Setext heading level 1
======================

Setext heading level 2
----------------------

A paragraph of text. A second line in the same paragraph.

A new paragraph after a blank line.  
This line follows a hard line break (two spaces at the end of the line above).

## Emphasis

*Italic with asterisks* and _italic with underscores_.

**Bold with asterisks** and __bold with underscores__.

***Bold and italic together***.

~~Strikethrough~~, H~2~O (subscript), x^2^ (superscript), and [small caps]{.smallcaps}.

[Underlined text]{.underline}

## Lists

- Bullet one
- Bullet two
    - Nested bullet (indented four spaces)
    - Another nested bullet
- Bullet three

1. First numbered item
2. Second numbered item
    1. Nested numbered item
3. Third numbered item

(a) Lettered item
(b) Another lettered item

Term one
:   Definition of term one.

Term two
:   Definition of term two.

## Quotes, rules, and code

> A block quotation.
> It can span several lines.

---

Inline `code` sits inside a sentence.

```python
def greet(name):
    return "Hello, " + name
```

## Poetry with hard line breaks

The water slips away at noon\
and leaves the shore a quiet floor,\
a scatter of shells and a bent spoon

## Links, images, and notes

A [link to a site](https://example.org "Optional title").

![A bar chart of rainfall by month](chart.png "Rainfall")

A sentence with a footnote.[^1]

[^1]: This is the text of the footnote.

## A table

| Month    | Rainfall (mm) | Sunny days |
|:---------|--------------:|-----------:|
| January  |            78 |         11 |
| February |            64 |         13 |

## Mathematics

Inline math: $E = mc^2$.

Displayed math:

$$\frac{a + b}{c - d}$$

## Raw HTML and escapes

A literal asterisk: \*not italic\*.

<div class="note">Raw HTML is passed through.</div>
