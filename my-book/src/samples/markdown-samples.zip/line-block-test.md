# Line block test

WARNING: this file is a test case. In the tested conversion filter, the line block
below (lines that start with a vertical bar) makes the import fail.

| The water slips away at noon
| and leaves the shore a quiet floor,
| a scatter of shells and a bent spoon
