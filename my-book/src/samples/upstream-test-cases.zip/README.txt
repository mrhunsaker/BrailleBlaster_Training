Reproducible test cases for import problems in BrailleBlaster's conversion script.
See UPSTREAM_ISSUES.md in the repository for what each case does and what was expected.
