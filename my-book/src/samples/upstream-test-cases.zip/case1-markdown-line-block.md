# Line block

| The water slips away at noon
| and leaves the shore a quiet floor
