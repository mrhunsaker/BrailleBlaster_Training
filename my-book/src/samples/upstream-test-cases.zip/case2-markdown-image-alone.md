# Image alone

Before.

![A bar chart of rainfall](chart.png "Rainfall")

After.
