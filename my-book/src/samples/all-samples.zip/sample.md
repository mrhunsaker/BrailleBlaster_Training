# Sample Markdown Document

## Introduction

This document demonstrates Markdown formatting.

### Key Features

- Headings at multiple levels
- **Bold text** for emphasis
- *Italic text* for light emphasis
- `Code formatting` for code snippets

### Lists

1. First ordered item
2. Second ordered item
   - Nested unordered item
   - Another nested item
3. Third ordered item

### Mathematics

Inline math: $E = mc^2$

Displayed math:

$$\frac{a + b}{c - d}$$

### Code Block

```python
def hello_world():
    print("Hello, World!")
```
