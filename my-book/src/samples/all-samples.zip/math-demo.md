# Pandoc Math Test

## Inline Math

The area of a circle is $A = \pi r^2$.

The circumference is $C = 2\pi r$.

## Displayed Math

The quadratic formula:

$$x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}$$

The Pythagorean theorem:

$$a^2 + b^2 = c^2$$

## Code with Math

In Python, you can calculate the area of a circle:

```python
import math

def circle_area(radius):
    return math.pi * radius ** 2

area = circle_area(5)
print(f"Area: {area}")
```

The formula used is $A = \pi r^2$.
